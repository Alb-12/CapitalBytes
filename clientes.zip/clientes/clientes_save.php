<?php

declare(strict_types=1);

session_start();
require __DIR__ . '/../db/db.php';

header('Content-Type: application/json; charset=utf-8');


function responder(array $payload, int $httpCode = 200): never
{
    http_response_code($httpCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (!in_array($_SESSION['rol'] ?? '', ['Administrador', 'Supervisor'], true)) {
    responder(['status' => 'error', 'message' => 'Sin permisos'], 403);
}

// 1. Validar y sanear campos requeridos
$camposRequeridos = [
    'cedula', 'nombre', 'apellido', 'direccion',
    'telefono', 'correo', 'nombre_garante',
    'telefono_garante', 'cedula_garante',
];

$datos = [];
foreach ($camposRequeridos as $campo) {
    $valor = trim((string) ($_POST[$campo] ?? ''));
    if ($valor === '') {
        responder([
            'status'  => 'error',
            'message' => "Este campo es requerido",
            'campo'   => $campo,
        ], 400);
    }
    $datos[$campo] = $valor;
}

// Validaciones de formato adicionales
if (!filter_var($datos['correo'], FILTER_VALIDATE_EMAIL)) {
    responder(['status' => 'error', 'message' => 'El correo no es válido', 'campo' => 'correo'], 400);
}

if (!ctype_digit($datos['cedula'])) {
    responder(['status' => 'error', 'message' => 'La cédula debe contener solo números', 'campo' => 'cedula'], 400);
}

if (!ctype_digit($datos['cedula_garante'])) {
    responder(['status' => 'error', 'message' => 'La cédula debe contener solo números', 'campo' => 'cedula_garante'], 400);
}
$rutaDestino = null;

if (isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
    if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        responder(['status' => 'error', 'message' => 'Error al subir la fotografía', 'campo' => 'foto'], 400);
    }

    // Límite de tamaño (5 MB)
    if ($_FILES['foto']['size'] > 5 * 1024 * 1024) {
        responder(['status' => 'error', 'message' => 'La fotografía no debe superar 5 MB', 'campo' => 'foto'], 400);
    }

     $tipoReal = getimagesize($_FILES['foto']['tmp_name']);
    $extensionesPermitidas = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];

    if ($tipoReal === false || !isset($extensionesPermitidas[$tipoReal['mime']])) {
        responder(['status' => 'error', 'message' => 'El archivo debe ser una imagen JPG, PNG o WEBP', 'campo' => 'foto'], 400);
    }

     $extension    = $extensionesPermitidas[$tipoReal['mime']];
    $nombreUnico  = bin2hex(random_bytes(16)) . '.' . $extension;
    $directorio   = __DIR__ . '/uploads/';
    $rutaAbsoluta = $directorio . $nombreUnico;

    if (!is_dir($directorio) && !mkdir($directorio, 0755, true) && !is_dir($directorio)) {
        responder(['status' => 'error', 'message' => 'No se pudo preparar el directorio de subida'], 500);
    }

    if (!move_uploaded_file($_FILES['foto']['tmp_name'], $rutaAbsoluta)) {
        responder(['status' => 'error', 'message' => 'Error al subir la fotografía'], 500);
    }

   $rutaDestino = 'uploads/' . $nombreUnico;
}

// 3. Insertar en la base de datos
try {
    $sql = "INSERT INTO clientes (
                nombre, apellido, cedula, direccion,
                telefono, correo, fotografia,
                nombre_garante, telefono_garante, cedula_garante
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        'ssssssssss',
        $datos['nombre'],
        $datos['apellido'],
        $datos['cedula'],
        $datos['direccion'],
        $datos['telefono'],
        $datos['correo'],
        $rutaDestino,
        $datos['nombre_garante'],
        $datos['telefono_garante'],
        $datos['cedula_garante']
    );
    $stmt->execute();
    $stmt->close();

    responder(['status' => 'success']);
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() === 1062) {
        responder(['status' => 'error', 'message' => 'Ya existe un cliente con esa cédula', 'campo' => 'cedula'], 409);
    }

     error_log('Error al guardar cliente: ' . $e->getMessage());
    responder(['status' => 'error', 'message' => 'Error interno al guardar el cliente'], 500);
} finally {
    $conn->close();
}