<?php

declare(strict_types=1);

include __DIR__ . '/../db/db.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$clientes = [];

try {
    $result = $conn->query('SELECT * FROM clientes ORDER BY nombre, apellido');

    
    $clientes = $result->fetch_all(MYSQLI_ASSOC);
} catch (mysqli_sql_exception $e) {
       error_log('Error al cargar clientes: ' . $e->getMessage());
}
?>